//
//  ViewController.swift
//  SearchAPIUsingCombine
//
//  Created by Swati Rout on 24/05/23.
//

import UIKit
import Combine

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource,UISearchResultsUpdating{
    
    @IBOutlet var tv: UITableView!
    var userInputSubject = PassthroughSubject<String,Never>()
    let searchController = UISearchController(searchResultsController: nil)
    var data: [Item] = []
    var filteredData: [Item] = []
    private var anycancellables: Set<AnyCancellable> = []
    override func viewDidLoad() {
        super.viewDidLoad()
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        navigationItem.searchController = searchController
        definesPresentationContext = true
        let nib = UINib(nibName: "ItemCell", bundle: .main)
        tv.register(nib, forCellReuseIdentifier: "ItemCell")
        userInputSubject.debounce(for: .seconds(0.5), scheduler: DispatchQueue.main)
            .removeDuplicates()
            .flatMap{
                query in
                self.fetchDataFromAPI(query: query)
                    .catch{
                        error -> Empty<[Item],Never> in
                        return Empty()
                    }
            }
            .receive(on: DispatchQueue.main)
            .sink{
                [weak self] items in
                self?.data = items
                print(items)
                self?.tv.reloadData()
            }
            .store(in: &anycancellables)
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering(){
            return filteredData.count
        }else {
            return data.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath) as! ItemCell
        let item:String
        if isFiltering(){
            item = filteredData[indexPath.row].title
        }else{
            item = data[indexPath.row].title
        }
        cell.titleLabel.text = item
        return cell
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text!)
        if let text = searchController.searchBar.text{
                userInputSubject.send(text)
        }
    }
    
    private func filterContentForSearchText(_ searchText: String) {
        filteredData = data.filter{
            item in
            return item.title.lowercased().contains(searchText.lowercased())
        }
        tv.reloadData()
        }

    private func isFiltering() -> Bool {
           return searchController.isActive && !searchBarIsEmpty()
       }
    
    private func searchBarIsEmpty() -> Bool {
            return searchController.searchBar.text?.isEmpty ?? true
        }
    
    func fetchDataFromAPI(query: String) -> AnyPublisher<[Item],Error> {
        guard let url = URL(string:"https://jsonplaceholder.typicode.com/todos/")else{
            return Fail(error: NSError(domain: "Invalid URL", code: 0, userInfo: nil)).eraseToAnyPublisher()
        }
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .decode(type: [Item].self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}

