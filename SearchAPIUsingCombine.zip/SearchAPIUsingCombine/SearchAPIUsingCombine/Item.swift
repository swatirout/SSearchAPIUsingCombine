//
//  Item.swift
//  SearchAPIUsingCombine
//
//  Created by Swati Rout on 24/05/23.
//

import Foundation
struct Item: Codable{
  let userId: Int
  let id: Int
let title: String
let completed: Bool
}
